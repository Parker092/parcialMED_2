package formularios;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import entidades.subcriptions;
import entidades.user;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFileChooser;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author PARKER (PC)
 */
public class frmPrincipal extends javax.swing.JFrame {

    public ArrayList<user> lUser;
    DefaultTableModel mdlTblUsers;//Tabla de USUARIOS
    DefaultTableModel mdlTblSubs;//Tabla de PRODUCTOS / SUBSCRIPCIONES
    int p;
    public frmPrincipal() {
        initComponents();
        lUser = new ArrayList<>();
        this.mdlTblUsers = (DefaultTableModel) this.jTblUser.getModel();
        this.mdlTblSubs = (DefaultTableModel) this.jTblProducto.getModel();
        this.cargaTblUser();
        //this.cargarTblSubs();
    }

    private void cargaTblUser(){            
        this.mdlTblUsers.setRowCount(0);
        for(int i=0; i<this.lUser.size(); i++)
        {
            String[] registro = {this.lUser.get(i).codeU, 
                this.lUser.get(i).nameU, 
                this.lUser.get(i).dateU
            };
            this.mdlTblUsers.addRow(registro);
        }
    }
    
    public void cargarTblSubs(){
        this.mdlTblSubs.getDataVector().removeAllElements();
        int user = this.jTblUser.getSelectedRow();
        int cant = this.lUser.get(user).lSubs.size();      
        for (int i = 0; i < cant; i++) {
            String [] registroPrds = {this.lUser.get(user).lSubs.get(i).nameSub,
                                                    this.lUser.get(user).lSubs.get(i).typeSub,
                                                    Double.toString(this.lUser.get(user).lSubs.get(i).monthSub),
                                                    Double.toString(this.lUser.get(user).lSubs.get(i).anualSub)
            };
            this.mdlTblSubs.addRow(registroPrds);
        }
    }
    
    public void crearPDF(){
        Document documento = new Document();  
        FileOutputStream ficheroPdf;
        try 
        {
            ficheroPdf = new FileOutputStream("C:\\Users\\palac\\OneDrive\\Escritorio\\Parcial 2 MED\\parcial2MED.pdf");
            PdfWriter.getInstance(
                       documento, 
                       ficheroPdf
                       ).setInitialLeading(20);
        }
            catch (DocumentException | FileNotFoundException ex) 
        {
            System.out.println(ex.toString());
        }
        try{
            documento.open();
            documento.add(new Paragraph("MANEJO DE ESTRUCTURA DE DATOS\n*** LISTADO DE USUARIOS ***"));
            for (int i = 0; i < this.lUser.size(); i++) {
                Paragraph parrafo2 = new Paragraph("Codigo: "+this.lUser.get(i).codeU+"\nNombre: "+this.lUser.get(i).nameU+"\nFecha Afiliacion: "+this.lUser.get(i).dateU);
                parrafo2.setAlignment(1);//el 1 es para centrar
                documento.add(parrafo2);
                documento.add(new Paragraph(" ")); //salto de linea
                PdfPTable tabla = new PdfPTable(4);
                tabla.addCell("Producto");
                tabla.addCell("Tipo Sub");
                tabla.addCell("Mensualidad");
                tabla.addCell("Pago Anual");
                for (int j = 0; j < this.lUser.get(i).lSubs.size(); j++) {
                    tabla.addCell(this.lUser.get(i).lSubs.get(j).nameSub);
                    tabla.addCell(this.lUser.get(i).lSubs.get(j).typeSub);
                    tabla.addCell(Double.toString(this.lUser.get(i).lSubs.get(j).monthSub));
                     tabla.addCell(Double.toString(this.lUser.get(i).lSubs.get(j).anualSub));
                }
                documento.add(tabla);
                documento.add(new Paragraph(" ")); //salto de linea
            }
            documento.close();
    }   catch (DocumentException ex) {
            Logger.getLogger(frmPrincipal.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel5 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jButton4 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jButton5 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jButton6 = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jButton7 = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        jButton8 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTblUser = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTblProducto = new javax.swing.JTable();

        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("CREAR CSV");

        jButton3.setText("CSV");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("EXPORTAR PDF");

        jButton4.setText("PDF");

        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("EXPORTAR HTML");

        jButton5.setText("HTML");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setSize(new java.awt.Dimension(720, 450));

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("PARCIAL 2 MANEJO DE ESTRUCTURAS DE DATOS");

        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setText("CARGAR CSV");

        jButton6.setText("CSV");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel7.setText("EXPORTAR PDF");

        jButton7.setText("PDF");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setText("EXPORTAR HTML");

        jButton8.setText("HTML");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        jTblUser.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "CODIGO", "NOMBRE", "FECHA"
            }
        ));
        jTblUser.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jTblUser.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTblUserMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTblUser);

        jTblProducto.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "PRODUCTO", "TIPO SUB", "MENSUALIDAD", "TOTAL AL AÑO"
            }
        ));
        jScrollPane2.setViewportView(jTblProducto);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel8))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(173, 173, 173))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                            .addGap(312, 312, 312)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 375, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 306, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(223, 223, 223))))
                .addContainerGap(17, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(jLabel7)
                    .addComponent(jLabel8))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton6)
                    .addComponent(jButton7)
                    .addComponent(jButton8))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(68, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // Crear CSV

    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        // Cargar CSV       
        File fArchivo = null;
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setCurrentDirectory(new File(System.getProperty("user.home")));
        int result = fileChooser.showOpenDialog(this);
        File selectedFile=null;
        if (result == JFileChooser.APPROVE_OPTION) 
        {
            selectedFile = fileChooser.getSelectedFile();
        }
        try 
        {
            Scanner scan = new Scanner(new File(selectedFile.getAbsolutePath()));
            scan.nextLine(); //funciona cuando hay encabezado
            int sub = 0;
            while (scan.hasNextLine()){
                String sLinea = scan.nextLine();
                String[] aLinea = sLinea.split(">");
                String[] aDatos = aLinea[1].split(",");
                if (aLinea[0].equals("<Usuario")) {
                    user nUser;
                        nUser = new user(aDatos[1], aDatos[2], aDatos[3]);
                        this.lUser.add(nUser);
                        sub = 0;
                }
                if (aLinea[0].equals("<Producto")) {
                        subcriptions nSub;
                        nSub = new subcriptions(aDatos[1], aDatos[2], Double.parseDouble(aDatos[3]), Double.parseDouble(aDatos[3])*12);
                        int i = (lUser.size() - 1);
                        if (sub == 0) {
                            this.lUser.get(i).lSubs = new ArrayList<>();                           
                        }
                        this.lUser.get(i).lSubs.add(nSub);
                        sub++;
                }               
            }
        }
        catch (Exception e) 
        {
        }
        
        this.cargaTblUser();
        
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jTblUserMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTblUserMouseClicked
        // SELECCION DE USUARIO - MOSTRAR PRODUCTO
        this.cargarTblSubs();
    }//GEN-LAST:event_jTblUserMouseClicked

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        //  CREAR PDF
        this.crearPDF();
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        //  CREAR HTML ARCHIVO
        {                                         
                PrintWriter pw = null;
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setCurrentDirectory(new File(System.getProperty("user.home")));
        int result = fileChooser.showOpenDialog(this);
        File selectedFile=null;
        if (result == JFileChooser.APPROVE_OPTION) 
        {
            selectedFile = fileChooser.getSelectedFile();
            System.out.println("Archivo seleccionado: " + selectedFile.getAbsolutePath());
        }
        try 
        {
            pw = new PrintWriter(new File(selectedFile.getAbsolutePath()));
        }
        catch (Exception e) 
        {
        }
        
        StringBuilder strLinea = new StringBuilder();
        // ARMAR EL ARCHIVO XML....
        strLinea.append("<html><body><table border='2'>" +"\n");
        for(int i=0; i<this.lUser.size(); i++)
        {
            strLinea.append("<tr><td><b>Codigo</td><td><b>Nombre</td><td><b>Fecha</td>" +"\n");
            strLinea.append("<tr>" +"\n");
            strLinea.append("<td>");
            strLinea.append(this.lUser.get(i).codeU);
            strLinea.append("</td>" +"\n");
            strLinea.append("<td>");
            strLinea.append(this.lUser.get(i).nameU);
            strLinea.append("</td>" +"\n");
            strLinea.append("<td>");
            strLinea.append(this.lUser.get(i).dateU);
            strLinea.append("</td>" +"\n");                       
            strLinea.append("</tr>" +"\n");
            strLinea.append("<tr><td><b>Producto</td><td><b>Tipo Sub</td><td><b>Pago Mensual</td><td><b>P. Anual</td>" +"\n");
            for (int j = 0; j < this.lUser.get(i).lSubs.size(); j++) {                
                strLinea.append("<tr>" +"\n");
            strLinea.append("<td>");
            strLinea.append(this.lUser.get(i).lSubs.get(j).nameSub);
            strLinea.append("</td>" +"\n");
                        strLinea.append("<td>");
            strLinea.append(this.lUser.get(i).lSubs.get(j).typeSub);
            strLinea.append("</td>" +"\n");
            strLinea.append("<td>");
            strLinea.append(Double.toString(this.lUser.get(i).lSubs.get(j).monthSub));
            strLinea.append("</td>" +"\n");
            strLinea.append("<td>");
            strLinea.append(Double.toString(this.lUser.get(i).lSubs.get(j).anualSub));
            strLinea.append("</td>" +"\n");
            strLinea.append("</tr>" +"\n");
            }
        }
        strLinea.append("</table></body></html>" +"\n");
        pw.write(strLinea.toString());
        pw.close();

    }
    }//GEN-LAST:event_jButton8ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(frmPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(frmPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(frmPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(frmPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new frmPrincipal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTblProducto;
    private javax.swing.JTable jTblUser;
    // End of variables declaration//GEN-END:variables
}
