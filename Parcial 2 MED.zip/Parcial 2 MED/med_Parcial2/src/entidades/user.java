package entidades;

import java.util.ArrayList;

/**
 *
 * @author PARKER (PC)
 */
public class user {
    public String codeU;
    public String nameU;
    public String dateU;
    public ArrayList<subcriptions> lSubs;
    
    public user (String code, String name, String dates){
        this.codeU = code;
        this.nameU = name;
        this.dateU = dates;
    }
}
