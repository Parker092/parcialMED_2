package entidades;

/**
 *
 * @author PARKER (PC)
 */
public class subcriptions {
    public String nameSub;
    public String typeSub;
    public double monthSub;
    public double anualSub;
    
    public subcriptions(String nameS, String typeS, double monthS, double anualS){
        this.nameSub = nameS;
        this.typeSub = typeS;
        this.monthSub = monthS;
        this.anualSub = anualS;
    }
}
